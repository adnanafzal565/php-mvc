<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 28/04/2018
 * Time: 3:09 PM
 */
?>

<form role="form" onsubmit="return login();">
    <?= Security::csrf_token(); ?>

    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" placeholder="Enter Email">
    </div>

    <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" placeholder="Enter Password">
    </div>

    <button type="submit" class="btn btn-primary">Login</button>
</form>
