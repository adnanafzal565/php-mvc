<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 29/04/2018
 * Time: 8:08 AM
 */
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login</title>

    <link href="<?= CSS; ?>bootstrap.css" rel="stylesheet">
    <link href="<?= ADMIN_CSS; ?>datepicker3.css" rel="stylesheet">
    <link href="<?= ADMIN_CSS; ?>styles.css" rel="stylesheet">

    <!--[if lt IE 9]>
    <script src="<?= ADMIN_JS; ?>html5shiv.js"></script>
    <script src="<?= ADMIN_JS; ?>respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div style="display: none;" id="url"><?= URL; ?></div>

<div class="row">
    <div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
        <div class="login-panel panel panel-default">
            <div class="panel-heading">Log in</div>
            <div class="panel-body">

                <form role="form" onsubmit="return adminLogin();">
                    <?= Security::csrf_token(); ?>
                    <fieldset>
                        <div class="form-group">
                            <input class="form-control" placeholder="E-mail" name="email" id="email" type="email" autofocus="">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Password" name="password" id="password" type="password" value="">
                        </div>
                        <input class="btn btn-primary" value="Login" type="submit" />
                    </fieldset>
                </form>

            </div>
        </div>
    </div><!-- /.col-->
</div><!-- /.row -->



<script src="<?= JS; ?>jquery-1.11.3.min.js"></script>
<script src="<?= JS; ?>bootstrap.js"></script>
<script src="<?= ADMIN_JS; ?>chart.min.js"></script>
<script src="<?= ADMIN_JS; ?>chart-data.js"></script>
<script src="<?= ADMIN_JS; ?>easypiechart.js"></script>
<script src="<?= ADMIN_JS; ?>easypiechart-data.js"></script>
<script src="<?= ADMIN_JS; ?>bootstrap-datepicker.js"></script>

<script src="<?= JS; ?>adnan.js"></script>
<script src="<?= JS; ?>sweetalert.min.js"></script>

<script>
    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){
            $(this).find('em:first').toggleClass("glyphicon-minus");
        });
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
        if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
        if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
</script>
</body>

</html>
