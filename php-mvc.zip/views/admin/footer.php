<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 29/04/2018
 * Time: 8:08 AM
 */
?>

</div>	<!--/.main-->

<script src="<?= JS; ?>jquery-1.11.3.min.js"></script>
<script src="<?= JS; ?>bootstrap.js"></script>
<script src="<?= ADMIN_JS; ?>chart.min.js"></script>
<script src="<?= ADMIN_JS; ?>chart-data.js"></script>
<script src="<?= ADMIN_JS; ?>easypiechart.js"></script>
<script src="<?= ADMIN_JS; ?>easypiechart-data.js"></script>
<script src="<?= ADMIN_JS; ?>bootstrap-datepicker.js"></script>

<script src="<?= JS; ?>adnan.js"></script>
<script src="<?= JS; ?>sweetalert.min.js"></script>

<script>
    $('#calendar').datepicker({
    });

    !function ($) {
        $(document).on("click","ul.nav li.parent > a > span.icon", function(){
            $(this).find('em:first').toggleClass("glyphicon-minus");
        });
        $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    $(window).on('resize', function () {
        if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
    })
    $(window).on('resize', function () {
        if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
    })
</script>
</body>

</html>
