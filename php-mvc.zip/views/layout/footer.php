<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 28/04/2018
 * Time: 1:48 PM
 */
?>

</div>

<script src="<?= JS; ?>jquery-1.11.3.min.js"></script>
<script src="<?= JS; ?>adnan.js"></script>
<script src="<?= JS; ?>sweetalert.min.js"></script>

</body>
</html>
