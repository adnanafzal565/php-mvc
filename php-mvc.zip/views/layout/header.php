<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 28/04/2018
 * Time: 1:48 PM
 */

$user = $this->get_logged_in_user();
?>

<html>
    <head>
        <title>ICO - <?= $this->title; ?></title>
        <link rel="stylesheet" href="<?= CSS; ?>bootstrap.css" />
        <link rel="stylesheet" href="<?= CSS; ?>sweetalert.css" />
    </head>

    <body>

    <div id="url" style="display: none;"><?= URL; ?></div>

        <nav class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <a class="navbar-brand" href="<?= URL; ?>">ICO</a>
            </div>
            <div>
                <ul class="nav navbar-nav navbar-left">
                    
                </ul>

                <ul class="nav navbar-nav navbar-right">

                    <?php if ($this->is_user_logged_in()) {?>

                        <li><a href="javascript:void(0);"><?= $user["name"]; ?></a></li>
                        <li><a href="<?= URL; ?>user/logout">Logout</a></li>

                    <?php } else { ?>

                        <li><a href="<?= URL; ?>user/login">Login</a></li>
                        <li><a href="<?= URL; ?>user/register">Register</a></li>

                    <?php }?>

                </ul>
            </div>
        </nav>

    <div class="container">
