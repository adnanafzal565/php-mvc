<?php
	define("URL", "http://localhost/ico-website/");
	define("VIEW", "views/");
	define("CSS", URL . "public/css/");
	define("JS", URL . "public/js/");
	define("IMG", URL . "public/img/");

    define("ADMIN_VIEW", VIEW . "admin/");
    define("ADMIN_CSS", URL . "public/admin/css/");
    define("ADMIN_JS", URL . "public/admin/js/");
    define("ADMIN_IMG", URL . "public/admin/img/");
	
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASS", "adnanafzal");
	define("DB_NAME", "ico_website");
?>