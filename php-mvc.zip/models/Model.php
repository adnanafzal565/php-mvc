<?php

class Model {
	protected $connection;
	
	public function __construct() {
		$this->connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	}
}