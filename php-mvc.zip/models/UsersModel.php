<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 28/04/2018
 * Time: 2:06 PM
 */

class UsersModel extends Model
{
    private $table = "users";

    public function register($name, $email, $password)
    {
        $sql = "INSERT INTO `" . $this->table . "`(`name`, `email`, `password`) VALUES ('$name', '$email', '$password')";
        mysqli_query($this->connection, $sql);

        return mysqli_insert_id($this->connection);
    }

    public function is_exists($email)
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `email` = '$email'";
        $result = mysqli_query($this->connection, $sql);

        return mysqli_num_rows($result) > 0;
    }

    public function login($email, $password)
    {
        $response = array();
        $response["error"] = "";
        $response["msg"] = "";

        $sql = "SELECT * FROM `" . $this->table . "` WHERE `email` = '$email' AND password = '$password'";
        $result = mysqli_query($this->connection, $sql);

        if (mysqli_num_rows($result) > 0)
        {
            $response["msg"] = mysqli_fetch_assoc($result);
        }
        else
        {
            $response["error"] = "Password does not match";
        }

        return $response;
    }

    public function get_user($user_id)
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `id` = '$user_id'";
        $result = mysqli_query($this->connection, $sql);

        if (mysqli_num_rows($result) > 0)
            return mysqli_fetch_assoc($result);
        else
            return null;
    }
}