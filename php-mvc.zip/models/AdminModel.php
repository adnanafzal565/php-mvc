<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 29/04/2018
 * Time: 8:08 AM
 */

class AdminModel extends Model
{
    private $table = "admins";

    public function login($email, $password)
    {
        $response = array();
        $response["error"] = "";
        $response["msg"] = "";

        $sql = "SELECT * FROM `" . $this->table . "` WHERE `email` = '$email' AND password = '$password'";
        $result = mysqli_query($this->connection, $sql);

        if (mysqli_num_rows($result) > 0)
        {
            $response["msg"] = mysqli_fetch_assoc($result);
        }
        else
        {
            $response["error"] = "Password does not match";
        }

        return $response;
    }

    public function get_admin($admin_id)
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `id` = '$admin_id'";
        $result = mysqli_query($this->connection, $sql);

        if (mysqli_num_rows($result) > 0)
            return mysqli_fetch_assoc($result);
        else
            return null;
    }
}