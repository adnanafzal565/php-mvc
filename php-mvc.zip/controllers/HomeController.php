<?php
    class HomeController extends Controller {
        public function index() {
        	require_once $this->get_header();
        	require_once $this->get_footer();
        }
    }
?>