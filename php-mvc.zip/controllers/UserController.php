<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 28/04/2018
 * Time: 1:55 PM
 */

class UserController extends Controller
{
    public function login()
    {
        if ($_POST)
        {
            $response = array();
            $response["error"] = "";
            $response["msg"] = "";

            $token = $_POST["token"];

            if (Security::is_valid_token($token))
            {
                $email = $_POST["email"];
                $password = $_POST["password"];

                $model_response = $this->load_model("UsersModel")->login($email, $password);
                $response["error"] = $model_response["error"];

                if ($response["error"] == "")
                {
                    $user_data = $model_response["msg"];
                    $this->login_user($user_data["id"]);
                    $response["msg"] = "Welcome " . $user_data["name"];
                }
            }
            else
            {
                $response["error"] = "Token mismatch";
            }

            echo json_encode($response);
        }
        else
        {
            require_once $this->get_header();
            require_once VIEW . 'user/login.php';
            require_once $this->get_footer();
        }
    }

    public function register()
    {
        if ($_POST)
        {
            $response = array();
            $response["error"] = "";
            $response["msg"] = "";

            $token = $_POST["token"];

            if (Security::is_valid_token($token))
            {
                $name = $_POST["name"];
                $email = $_POST["email"];
                $password = $_POST["password"];

                $UsersModel = $this->load_model("UsersModel");
                if ($UsersModel->is_exists($email))
                {
                    $response["error"] = "Email already exists";
                }
                else
                {
                    $user_id = $UsersModel->register($name, $email, $password);
                    $this->login_user($user_id);

                    $response["msg"] = "Account has been created";
                }
            }
            else
            {
                $response["error"] = "Token mismatch";
            }

            echo json_encode($response);
        }
        else
        {
            require_once $this->get_header();
            require_once VIEW . 'user/register.php';
            require_once $this->get_footer();
        }
    }

    public function login_user($user_id)
    {
        $_SESSION["user"] = $user_id;
    }
}