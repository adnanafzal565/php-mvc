<?php
	class Controller {
		protected $header;
        protected $footer;
        protected $title;
		
		public function __construct() {
			$this->header = VIEW . "layout/header.php";
            $this->footer = VIEW . "layout/footer.php";

            $this->title = "Home";
		}
		
		protected function get_header() {
            return $this->header;
        }

        protected function get_footer() {
            return $this->footer;
        }

		public function send_mail($to, $subject, $body) {
            require 'public/PHPMailer/PHPMailerAutoload.php';

            $mail = new PHPMailer;

            //$mail->SMTPDebug = 3;                               // Enable verbose debug output

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'adnanafzal565test@gmail.com';                 // SMTP username
            $mail->Password = '';                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to

            $mail->setFrom('adnanafzal565test@gmail.com', 'Adnan Afzal');
            $mail->addAddress($to);     // Add a recipient
            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = $subject;
            $mail->Body    = $body;

            if(!$mail->send()) {
                die('Mailer Error: ' . $mail->ErrorInfo);
            }
        }
		
		protected function load_model($model_name) {
			$path = "models/" . $model_name . ".php";
			if (file_exists($path)) {
				require_once($path);
				return new $model_name();
			} else {
				return null;
			}
		}

        public function is_user_logged_in() {
            return isset($_SESSION["user"]);
        }

        public function is_admin_logged_in() {
            return isset($_SESSION["admin"]);
        }

        public function get_logged_in_user()
        {
            if ($this->is_user_logged_in())
                return $this->load_model("UsersModel")->get_user($_SESSION["user"]);
            else
                return null;
        }

        public function logout()
        {
            unset($_SESSION["user"]);
            unset($_SESSION["admin"]);

            session_destroy();
            header("Location: " . URL);
        }
	}
?>