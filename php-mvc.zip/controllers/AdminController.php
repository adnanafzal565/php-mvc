<?php
/**
 * Created by PhpStorm.
 * User: Adnan Afzal
 * Date: 29/04/2018
 * Time: 8:03 AM
 */

class AdminController extends Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->header = ADMIN_VIEW . "header.php";
        $this->footer = ADMIN_VIEW . "footer.php";
    }

    public function index()
    {
        if ($this->is_admin_logged_in())
        {
            header("Location: " . URL . "admin/dashboard");
        }
        else
        {
            $this->goto_login();
        }
    }

    public function login()
    {
        if ($_POST)
        {
            $response = array();
            $response["error"] = "";
            $response["msg"] = "";

            $token = $_POST["token"];

            if (Security::is_valid_token($token))
            {
                $email = $_POST["email"];
                $password = $_POST["password"];

                $model_response = $this->load_model("AdminModel")->login($email, $password);
                $response["error"] = $model_response["error"];

                if ($response["error"] == "")
                {
                    $admin_data = $model_response["msg"];
                    $this->login_admin($admin_data["id"]);
                    $response["msg"] = "Welcome " . $admin_data["name"];
                }
            }
            else
            {
                $response["error"] = "Token mismatch";
            }

            echo json_encode($response);
        }
        else
        {
            require_once ADMIN_VIEW . 'login.php';
        }
    }

    public function login_admin($admin_id)
    {
        $_SESSION["admin"] = $admin_id;
    }

    public function dashboard()
    {
        if ($this->is_admin_logged_in())
        {
            require_once $this->get_header();
            require_once ADMIN_VIEW . 'dashboard.php';
            require_once $this->get_footer();
        }
        else
        {
            $this->goto_login();
        }
    }

    public function goto_login()
    {
        header("Location: " . URL . "admin/login");
    }

    public function get_logged_in_admin()
    {
        if ($this->is_admin_logged_in())
            return $this->load_model("AdminModel")->get_admin($_SESSION["admin"]);
        else
            return null;
    }
}