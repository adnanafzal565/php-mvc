/**
 * Created by Adnan on 07/01/2018.
 */

$(function () {
    window.url = $("#url").text();
});

function callAjax(url, data, method, callBack) {
    $.ajax({
        url: url,
        method: method,
        data: data,
        success: function (response) {
            console.log(response);
            callBack(JSON.parse(response));
        }
    });
}

function register() {
    var name = $("#name").val();
    var email = $("#email").val();
    var password = $("#password").val();
    var token = $("#token").val();

    callAjax(window.url + "user/register", {"name": name, "email": email, "password": password, "token": token}, "POST", function (response) {
        if (response.error == "")
        {

            swal("Registered", response.msg, "success")
                .then((value) => {
                window.location.href = window.url;
            });
        }
        else
        {
            swal("Error", response.error, "error");
        }
    });

    return false;
}

function login() {
    var email = $("#email").val();
    var password = $("#password").val();
    var token = $("#token").val();

    callAjax(window.url + "user/login", {"email": email, "password": password, "token": token}, "POST", function (response) {
        if (response.error == "")
        {

            swal("Logged in", response.msg, "success")
                .then((value) => {
                window.location.href = window.url;
        });
        }
        else
        {
            swal("Error", response.error, "error");
        }
    });

    return false;
}

function adminLogin() {
    var email = $("#email").val();
    var password = $("#password").val();
    var token = $("#token").val();

    callAjax(window.url + "admin/login", {"email": email, "password": password, "token": token}, "POST", function (response) {
        if (response.error == "")
        {

            swal("Logged in", response.msg, "success")
                .then((value) => {
                window.location.href = window.url + "admin/dashboard";
            });
        }
        else
        {
            swal("Error", response.error, "error");
        }
    });

    return false;
}